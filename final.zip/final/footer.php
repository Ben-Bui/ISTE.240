    <!-- Footer content -->
    <fieldset>
        <!-- Add Citation -->
        <legend>Citation </legend>        
        <ul class="formelement">
            <li><a href="http://solace.ist.rit.edu/~btb4516/ISTE240/final/citation/index.php">Citation</a></li>
        </ul>
    </fieldset>

