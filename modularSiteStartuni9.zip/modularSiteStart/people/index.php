<?php

	$page = "people";
    $path = "../";
	include($path . 'assets/inc/header.php');
	include($path . 'assets/inc/nav.php');
?>

				<h1>People page stuff...</h1> 
				<div>People stuff</div>
<?php
	include($path . 'assets/inc/footer.php');
?>