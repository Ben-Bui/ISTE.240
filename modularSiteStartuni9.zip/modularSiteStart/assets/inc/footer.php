</div> <!-- end innertube -->
		</div> <!-- end contentcolumn -->
	</div><!-- end contentwrapper -->
</section><!-- end maincontainer -->
<footer id="bottom"> 
	<div id="bottomtext">&copy; Us, some important information here... 
		<a href="./citations.html" style="color:#b4c1d1;">Citations</a>		
	</div> 
</footer> 
</body> 
</html> 