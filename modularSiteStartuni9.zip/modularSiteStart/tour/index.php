<?php

	$page = "Tour";
    $path = "../";
	include($path . 'assets/inc/header.php');
	include($path . 'assets/inc/nav.php');
?>

				<h1>Tour</h1> 
				<div>Tour stuff</div>
<?php
	include($path . 'assets/inc/footer.php');
?>