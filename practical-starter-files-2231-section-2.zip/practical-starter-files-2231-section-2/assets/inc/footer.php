<?php
echo "Copyright 2023 Rate my shirt"
?>