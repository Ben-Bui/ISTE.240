<?php

    $page = "about";
    $path = "";
	include($path . 'assets/inc/header.php');
    include($path . 'assets/inc/nav.php');
?>

				<h1>About Page</h1> 
				<div>About Page</div>
<?php 
	include($path . 'assets/inc/footer.php');
?>
