<?php

	$page = "home";
    $path = "";
	include($path . 'assets/inc/header.php');
	include($path . 'assets/inc/nav.php');
?>

				<h1>Home page stuff...</h1> 
				<div>(eventually, each page will be some includes and a db call only!)</div>
<?php
	include($path . 'assets/inc/footer.php');
?>